package com.example.api;

public class GetContacts {
    public void execute() {
    }
}
